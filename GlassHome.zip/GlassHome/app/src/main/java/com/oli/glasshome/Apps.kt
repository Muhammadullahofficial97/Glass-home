package com.oli.glasshome

import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val icon: Drawable, val pkg: String, val cls: String) {
    val key get() = "$pkg/$cls"
}

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppItem>()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val root: LinearLayout, val img: ImageView, val txt: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val d = c.resources.displayMetrics.density
        val ll = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val img = ImageView(c)
        ll.addView(img, LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()))
        val txt = TextView(c).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, 0x66000000)
            setPadding((2 * d).toInt(), (6 * d).toInt(), (2 * d).toInt(), 0)
        }
        ll.addView(txt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ll.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(120).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator()).start()
            }
            false
        }
        return VH(ll, img, txt)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.img.setImageDrawable(item.icon)
        h.txt.text = item.label
        h.root.setOnClickListener { onClick(item) }
        h.root.setOnLongClickListener { onLong(item); true }
    }

    override fun getItemCount() = items.size
}
