package com.oli.glasshome

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.widget.FrameLayout

/**
 * Liquid-glass panel: blurred wallpaper + frosted tint + bright edge.
 * Add your content with addView(); it sits on top of the glass.
 */
class GlassPanel(ctx: Context, private val radiusPx: Float) : FrameLayout(ctx) {

    private class Backdrop(c: Context) : View(c) {
        private val loc = IntArray(2)
        override fun onDraw(canvas: Canvas) {
            val bmp = Wallpaper.bitmap ?: return
            getLocationInWindow(loc)
            canvas.save()
            canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
            canvas.drawBitmap(bmp, 0f, 0f, null)
            canvas.restore()
        }
    }

    private val backdrop = Backdrop(ctx)
    private val last = intArrayOf(-99999, -99999)
    private val tmp = IntArray(2)

    private val preDraw = ViewTreeObserver.OnPreDrawListener {
        getLocationInWindow(tmp)
        if (tmp[0] != last[0] || tmp[1] != last[1]) {
            last[0] = tmp[0]; last[1] = tmp[1]
            backdrop.invalidate()
        }
        true
    }

    init {
        val d = ctx.resources.displayMetrics.density
        addView(backdrop, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        backdrop.setRenderEffect(RenderEffect.createBlurEffect(60f, 60f, Shader.TileMode.CLAMP))

        val tint = View(ctx)
        tint.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0x66FFFFFF, 0x1FFFFFFF, 0x33FFFFFF)
        ).apply {
            cornerRadius = radiusPx
            setStroke((1.2f * d).toInt().coerceAtLeast(1), 0x99FFFFFF.toInt())
        }
        addView(tint, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, radiusPx)
            }
        }
        clipToOutline = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        viewTreeObserver.addOnPreDrawListener(preDraw)
    }

    override fun onDetachedFromWindow() {
        viewTreeObserver.removeOnPreDrawListener(preDraw)
        super.onDetachedFromWindow()
    }
}
